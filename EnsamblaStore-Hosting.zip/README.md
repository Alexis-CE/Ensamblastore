# EnsamblaStore (form.mx)

Tienda de computadoras y componentes 

## Estructura
```
form.mx/
├── index.php            inicio, login/registro (modal), carrito y pedidos
├── seccion.php          catalogos, carrito, soporte y acerca de
├── admin.php            panel privado para administrar el catalogo
├── includes/conexion.php  conexion a la base de datos (base: dat)
├── includes/seo_head.php  títulos, metadatos sociales, canonical y GA4 opcional
├── 404.php              página de error personalizada
├── robots.txt           reglas de rastreo para buscadores
├── sitemap.xml          páginas públicas para indexación
├── favicon.svg          icono del sitio
├── database/
│   └── instalacion_completa.sql esquema, 30 productos y precios
├── secciones/           partes de cada pagina (hero, computadoras, componentes, carrito, soporte, acerca)
├── css/estilos.css
├── js/secciones.js
└── assets/
    ├── marcas/          logos SVG del slider
    ├── modelos/         modelo 3D del hero
    ├── seo/              imagen Open Graph
    └── productos/       fotos de productos (ver LEEME.txt)
```

## Instalación en hosting PHP

Este proyecto requiere un servidor con PHP 8 o posterior, MySQL/MariaDB, la
extensión `mysqli` y sesiones PHP. En Apache también se necesita `mod_rewrite`
y permitir reglas `.htaccess`. No es compatible con Netlify Drop: Netlify no
ejecuta los archivos PHP ni conecta esta aplicación a su base de datos.

1. Crea una base de datos y un usuario MySQL para la aplicación.
2. Importa `database/instalacion_completa.sql` en el servidor MySQL.
3. En `includes/conexion.php`, configura el host, usuario, contraseña y nombre
   de la base de datos que te proporcionó tu hosting. No publiques las
   credenciales.
4. Sube el contenido de este proyecto al directorio público del sitio,
   conservando su estructura. Si lo instalas en una subcarpeta, ajusta la regla
   `ErrorDocument` de `.htaccess` a la ruta de `404.php`.
5. Registra una cuenta desde el sitio. Para habilitar el panel, cambia su rol a
   `admin` en MySQL, por ejemplo:
   `UPDATE usuarios SET rol = 'admin' WHERE usuario = 'TU_USUARIO';`
6. Sustituye `tudominio.com` por el dominio definitivo en `includes/seo_head.php`,
   `robots.txt` y `sitemap.xml`.

El ZIP del proyecto incluye el código fuente, los recursos y el SQL de
instalación; no incluye datos de acceso del hosting ni una copia de la base de
datos ya cargada.
